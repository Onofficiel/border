//!wrt

const binPath = "C:/system/local/bin/border";

w96.evt.sys.on("init-complete", async () => {
  w96.state.processes.find(e => e && e.title === "shell36").terminate();

  let msg = w96.ui.MsgBoxSimple.idleProgress("Border", "Fetching Border...");
  const binContent = await (
    await fetch("https://onofficiel.github.io/border/w96/stable/border_v3")
  ).text();
  msg.closeDialog();

  msg = w96.ui.MsgBoxSimple.idleProgress("Border", "Downloading Border...");
  await FS.writestr(binPath, binContent);
  msg.closeDialog();

  w96.sys.execFile(binPath);
});
